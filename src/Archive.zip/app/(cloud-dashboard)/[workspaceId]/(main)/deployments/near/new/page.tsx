import { notFound } from "next/navigation";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CreateNEARNodeForm } from "../components/create-near-node-form";
import { getClientVersions } from "@/services/get-client-versions";
import { getWorkspace } from "@/services/get-workspace";
import { Roles } from "@/enums";

export default async function CreateNewBitcoinNodePage({
  params,
}: {
  params: { workspaceId: string };
}) {
  const { workspaceId } = params;
  const { role } = await getWorkspace(workspaceId);

  if (role === Roles.Reader) notFound();

  const { versions } = await getClientVersions({
    protocol: "near",
    component: "node",
    client: "nearcore",
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create New NEAR Node</CardTitle>
      </CardHeader>
      <CardContent>
        <CreateNEARNodeForm images={versions} />
      </CardContent>
    </Card>
  );
}
